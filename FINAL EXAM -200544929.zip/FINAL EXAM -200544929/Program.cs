﻿namespace FinalExam_200544929
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Standard obj=new Standard();

            obj.usercardID = 1;
            obj.frstName = "DHRUV";
            obj.lastName = "PATEL";
            obj.address = "georgian drive";
            obj.phoneNumber = "7359029999";
            obj.PostCode = "L4M 7B6";
            obj.LibraryCardNbr = "27778";

            Resource r1 = new Resource();
            r1.Title = "paper";
            r1.Code = "S4344";
            r1.Description = "A Player";
            r1.DatePublished = DateTime.Now;
            r1.Publisher = "A player.inc";

            Resource r2 = new Resource();
            r1.Title = "newspaper";
            r1.Code = "S333";
            r1.Description = "Hot space";
            r1.DatePublished = DateTime.Now;
            r1.Publisher = "web.inc";

            List<Resource> resources=new List<Resource>();
            resources.Add(r1);
            resources.Add(r2);

            Borrowing b1 = new Borrowing(obj.usercardID.ToString(), resources);
            b1.StartDate = DateTime.Now;
            b1.EndDate = b1.StartDate.AddDays(10);


        }
    }
}