using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalExam_200544929
{
    internal class Standard:User,iBillable
    {
        public string PostCode;
        public string LibraryCardNbr;
        private string CreditCardNbr;

        public Standard()
    {
        PostCode = string.Empty;
        LibraryCardNbr = string.Empty;
        CreditCardNbr = string.Empty;
    }

        public bool ProcessPayment()
        {
            return true;
        }
    }
}