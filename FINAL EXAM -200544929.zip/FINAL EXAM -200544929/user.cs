using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalExam_200544929
{
    internal abstract class User
    {
        public int usercardID;
        public string frstName;
        public string lastName;
        public string address;
        public string phoneNumber;

        public User()
        {
            frstName=string.Empty;
            lastName=string.Empty;
            address=string.Empty;
            phoneNumber=string.Empty;
        }

        public void PrintBorrowingHistory()
        {

        }

        public bool SendReminder()
        {
            return true;
        }
    }
}